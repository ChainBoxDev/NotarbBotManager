#!/bin/bash
set -e

BOT_EXECUTABLE="./notarb_bot_runner"
SESSION_NAME="chainbox_tg_notarb"

echo "🤖 Starting NOTARB Telegram Bot..."

# Check if executable exists
if [ ! -f "$BOT_EXECUTABLE" ]; then
    echo "❌ Bot executable not found!"
    echo "Please run ./install.sh first"
    exit 1
fi

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "❌ Configuration file (.env) not found!"
    echo "Please run ./install.sh first"
    exit 1
fi

# Make sure it's executable
chmod +x $BOT_EXECUTABLE

echo "▶️ Starting bot in screen session..."

# Kill existing session if it exists
screen -S $SESSION_NAME -X quit 2>/dev/null || true

# Start bot in new screen session
screen -dmS $SESSION_NAME $BOT_EXECUTABLE

sleep 2

# Check if session is running
if screen -list | grep -q "$SESSION_NAME"; then
    echo "✅ Bot started successfully!"
    echo ""
    echo "📋 Useful commands:"
    echo "  View logs: screen -r $SESSION_NAME"
    echo "  Stop bot:  screen -S $SESSION_NAME -X quit"
    echo "  Check status: screen -list"
else
    echo "❌ Failed to start bot"
    echo "Check logs: screen -r $SESSION_NAME"
    exit 1
fi
