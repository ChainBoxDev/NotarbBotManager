#!/bin/bash
# NOTARB Bot - Installer Script
# This script sets up the necessary environment for the bot on a fresh server.
set -e

echo "🔐 NOTARB Bot Installer"
echo "======================"

# System requirements check
echo "📋 System Requirements:"
echo "  • Linux x86_64 (Ubuntu 16.04+, CentOS 7+, Debian 9+)"
echo "  • 512MB RAM minimum (1GB recommended)"
echo "  • 100MB disk space"
echo "  • Internet connection for license validation"
echo "  • Root/sudo access for package installation"
echo ""

# Check and install required packages
echo "🔍 Checking required packages..."

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install packages based on distribution
install_packages() {
    if command_exists apt-get; then
        # Ubuntu/Debian
        echo "📦 Installing packages using apt-get..."
        sudo apt-get update -qq
        sudo apt-get install -y screen nano curl wget unzip procps ca-certificates
    elif command_exists yum; then
        # CentOS/RHEL
        echo "📦 Installing packages using yum..."
        sudo yum install -y screen nano curl wget unzip procps ca-certificates
    elif command_exists dnf; then
        # Fedora/Modern RHEL
        echo "📦 Installing packages using dnf..."
        sudo dnf install -y screen nano curl wget unzip procps ca-certificates
    else
        echo "⚠️  Could not detect package manager. Please install the following packages manually:"
        echo "   - For Ubuntu/Debian: sudo apt-get install screen nano curl wget unzip procps ca-certificates"
        echo "   - For CentOS/RHEL: sudo yum install screen nano curl wget unzip procps ca-certificates"
        echo "   - For Fedora: sudo dnf install screen nano curl wget unzip procps ca-certificates"
        return 1
    fi
}

# List of required packages
required_packages=("screen" "nano" "curl" "unzip")
missing_packages=()

# Check each required package
for package in "${required_packages[@]}"; do
    if ! command_exists "$package"; then
        echo "❌ '$package' not found"
        missing_packages+=("$package")
    else
        echo "✅ '$package' is installed"
    fi
done

# Install missing packages if any
if [ ${#missing_packages[@]} -gt 0 ]; then
    echo ""
    echo "📦 Installing missing packages: ${missing_packages[*]}"
    install_packages
    
    # Verify installation
    echo "🔍 Verifying installation..."
    for package in "${missing_packages[@]}"; do
        if command_exists "$package"; then
            echo "✅ '$package' successfully installed"
        else
            echo "❌ Failed to install '$package'"
            echo "⚠️  Please install manually: sudo apt-get install $package"
        fi
    done
fi

echo "✅ All required packages are available"
echo ""

# Check if executable exists
if [ ! -f "./notarb_bot_runner" ]; then
    echo "❌ Bot executable not found!"
    echo "Please ensure notarb_bot_runner is in the current directory."
    exit 1
fi

# Make executable
chmod +x ./notarb_bot_runner

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "📝 Creating configuration file..."
    
    # Create .env.example if it doesn't exist
    if [ ! -f ".env.example" ]; then
        cat > .env.example << 'EOF'
# NOTARB Telegram Bot Configuration
# =================================

# License Configuration
LICENSE_KEY=your_license_key_here

# Telegram Bot Configuration  
TELEGRAM_TOKEN=your_telegram_bot_token_here
ALLOWED_USER_IDS=your_telegram_user_id_here
EOF
    fi
    
    cp .env.example .env
    
    echo ""
    echo "⚙️ Please configure the following in .env file:"
    echo "1. LICENSE_KEY - Your license key"
    echo "2. TELEGRAM_TOKEN - Your bot token from @BotFather"
    echo "3. ALLOWED_USER_IDS - Your Telegram user ID"
    echo ""
    echo "💡 MACHINE_ID is automatically generated, no manual setup needed"
    echo ""
    echo "📖 See README.md for detailed setup instructions"
    echo ""
    echo "⚠️  IMPORTANT: After configuration, send /start to your bot to activate it!"
else
    echo "✅ Configuration file already exists"
fi

echo ""
echo "🎉 Installation completed!"
echo "▶️ You can now run: ./start.sh"
