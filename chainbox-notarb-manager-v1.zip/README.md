# NOTARB Telegram Bot - User Guide

## Quick Setup (6 Steps)

### 1. Extract Files
Extract all files to a directory on your server.
```bash
unzip chainbox-notarb-manager-v1.zip
```

### 2. Create Telegram Bot
1. Search for @BotFather on Telegram (https://t.me/BotFather)
2. Click Start and send `/newbot` and follow instructions
3. Copy the bot token (Example Token: 1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ)
4. **IMPORTANT:** Click your bot and send `/start` to activate it


### 3. Get Your User ID
1. Search for @userinfobot on Telegram (https://t.me/userinfobot)
2. Click Start and send `/start` to get your user ID number (Example ID: 1234567890)

### 4. Install Bot
```bash
chmod +x install.sh start.sh
./install.sh
```

### 5. Configure Bot
Edit the `.env` file:
```bash
nano .env
```

Fill in your information:
```env
LICENSE_KEY=your_license_key_here
TELEGRAM_TOKEN=your_telegram_bot_token_here  
ALLOWED_USER_IDS=your_telegram_user_id_here
```

### 6. Start Bot
```bash
./start.sh
```

## Commands

- **Start bot:** `./start.sh`
- **View logs:** `screen -r chainbox_tg_notarb`
 **Check logs:** `cd logs && cat bot.log`
- **Stop bot:** `screen -S chainbox_tg_notarb -X quit`
- **Check status:** `screen -list`

### Working with Screen (Log Viewing)
When you use `screen -r chainbox_tg_notarb` to view logs:
- **To detach from screen (leave bot running):** Press `Ctrl+A` then `D`
- **To stop the bot completely:** Press `Ctrl+C` or use the stop command above
- **To scroll up/down in logs:** Press `Ctrl+A` then `[`, use arrow keys, press `Esc` to exit scroll mode

## Troubleshooting

### Bot doesn't respond
1. Make sure you sent `/start` to the Telegram bot
2. Check your user ID is correct in `.env`
3. Verify bot token is correct in `.env`

### Permission denied
```bash
chmod +x notarb_bot_runner install.sh start.sh
```

### Screen not found
```bash
# Install screen
sudo apt-get install screen  # Ubuntu/Debian
sudo yum install screen      # CentOS/RHEL
sudo dnf install screen      # Fedora
```

### License Issues
- **"LICENSE_KEY not configured"** → Add license key to `.env`
- **"License expired"** → Contact chainbox.dev to renew
- **"License is bound to another machine"** → Contact chainbox.dev

## File Structure
```
chainbox-notarb-manager/
├── notarb_bot_runner      # Main bot executable
├── install.sh          # Installation script  
├── start.sh           # Start script
├── .env.example       # Configuration template
└── README.md         # This file
```

## Support
For support, contact **chainbox.dev**
